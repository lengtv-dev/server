const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 10000;

// เปิดใช้งาน CORS สำหรับทุก Origin เพื่อให้เว็บหน้าบ้านเรียกใช้ Proxy ได้แบบไม่ติดขัด
app.use(cors());

// เสิร์ฟไฟล์หน้าบ้านจากโฟลเดอร์ public
app.use(express.static("public"));

app.get("/proxy", async (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) {
    return res.status(400).send("Error: Missing 'url' parameter");
  }

  try {
    // กำหนด Headers ที่เว็บต้นทางต้องการตรวจสอบ
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Referer": "https://madoball.com/",
      "Origin": "https://madoball.com",
      "Accept": "*/*",
      "Accept-Language": "en-US,en;q=0.9"
    };

    // ใช้ Native Fetch ของ Node.js (ไม่ต้องลง library เพิ่มใน Node v18+)
    const response = await fetch(targetUrl, { headers });

    if (!response.ok) {
      return res.status(response.status).send(`Target server responded with code ${response.status}`);
    }

    // แยกแยะกรณีจัดการไฟล์วิดีโอ (.ts) และไฟล์ Playlist (.m3u8)
    const urlWithoutQuery = targetUrl.split("?")[0];

    if (urlWithoutQuery.endsWith(".ts")) {
      // สำหรับไฟล์ .ts ให้ทำ Stream Pipe ส่งต่อข้อมูลทันทีเพื่อประหยัด Memory
      res.setHeader("Content-Type", response.headers.get("content-type") || "video/MP2T");
      
      const reader = response.body.getReader();
      const stream = new ReadableStream({
        async start(controller) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            controller.enqueue(value);
          }
          controller.close();
        }
      });
      
      const nodeStream = require("stream").Readable.fromWeb(stream);
      nodeStream.pipe(res);
      return;
    }

    // สำหรับไฟล์ .m3u8 (Playlist) ต้องนำมาแปลงลิ้งก์ข้างในก่อน
    let text = await response.text();
    const baseUrl = targetUrl.substring(0, targetUrl.lastIndexOf("/") + 1);

    // ทำการ rewrite บรรทัดที่เป็น url ให้วิ่งผ่าน proxy ของเรา
    const rewrittenText = text.split("\n").map(line => {
      const trimmedLine = line.trim();
      
      // ข้ามบรรทัดที่เป็นคอมเมนต์ยกเว้นกรณีที่เป็นข้อมูลลิ้งก์พิเศษ
      if (trimmedLine.startsWith("#") || trimmedLine === "") {
        return line;
      }

      // ตรวจสอบว่าเป็นลิ้งก์เต็ม (Absolute) หรือลิ้งก์สั้น (Relative)
      let fullUrl = trimmedLine;
      if (!trimmedLine.startsWith("http://") && !trimmedLine.startsWith("https://")) {
        fullUrl = baseUrl + trimmedLine;
      }

      // ครอบลิ้งก์ด้วย Proxy URL ของเราเอง
      return `/proxy?url=${encodeURIComponent(fullUrl)}`;
    }).join("\n");

    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.send(rewrittenText);

  } catch (err) {
    console.error("Proxy error:", err.message);
    res.status(500).send("Proxy internal error");
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Full-System Proxy Server is running on http://localhost:${PORT}`);
});
